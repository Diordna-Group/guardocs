use mysql;
INSERT INTO `user` VALUES ('localhost','debian-sys-maint','*83F36D186175744F677957AE691A060458DCDC5C','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','Y','N','N','N','N','N','','','','',0,0,0,0);
flush privileges;

