#!/usr/bin/perl

use strict;
use lib qw(/home/cvs/archivista/jobs);
use Archivista::Config;
my $config = Archivista::Config->new;
my $pw = $config->get("MYSQL_PWD");

print "ArchivistaBox 64Bit conversion tool\n";
print "Do you want to upgrade? (Y/n)";
my $res=<>;
chomp $res;
if ($res eq "Y") {
  print "now upgrading mysql databases for ArchivistaBox 64bit\n";
  system("mysql_fix_privilege_tables --user=root --password=$pw");
  system("mysqlcheck --user=root --password=$pw --all-databases");
  system("mysql_upgrade --user=root -password=$pw --force");
	system("mysql -uroot -p$pw <useradd.sql");
	system("perl /home/cvs/archivista/jobs/avdbutility.pl checkdb");
	print "conversion finished! You now can work with ArchivistaBox 64Bit.\n";
} else {
  print "Wrong key, you have to use 'Y', restart it again!\n";
}



